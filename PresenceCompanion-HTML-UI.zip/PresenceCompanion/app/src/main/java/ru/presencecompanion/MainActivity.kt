package ru.presencecompanion

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Интерфейс — HTML (assets/index.html) в WebView.
 * Вся логика присутствия, плавающая панель и захват экрана остаются нативными,
 * HTML только показывает состояние и вызывает методы моста window.Android.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val KEY_AWAY_START_MS = "away_start_ms"
        private const val KEY_TOTAL_AWAY_MS = "total_away_ms"
        private const val KEY_EFFECTIVE_PENALTY_MS = "effective_penalty_ms"
        private const val KEY_THRESHOLD_COUNT = "threshold_triggered_count"
        private const val KEY_MULTIPLIER_ACTIVE = "multiplier_active"
    }

    private lateinit var webView: WebView

    private var statusText = "PRESENCE COMPANION\nГотов к работе"
    private var awayStartMs: Long? = null
    private var totalAwayMs: Long = 0L
    private var effectivePenaltyMs: Long = 0L
    private var thresholdTriggeredCount: Int = 0
    private var multiplierActive: Boolean = false

    private val eventLog = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    private val thresholdMs = 5_000L
    private val timerHandler = Handler(Looper.getMainLooper())

    // Тикер работает всё время жизни Activity: HTML перерисовывается каждые 100 мс
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            pushState()
            timerHandler.postDelayed(this, 100L)
        }
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            launchScreenCapturePrompt()
        }

    private val capturePermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val service = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                }
                startForegroundService(service)
                setStatus("Захват экрана запущен...")
            } else {
                setStatus("Разрешение на захват не получено")
            }
        }

    /** Мост для JS. Методы вызываются из потока WebView, поэтому всё уходит в UI-поток. */
    inner class Bridge {
        @JavascriptInterface fun requestState() = runOnUiThread { pushState() }
        @JavascriptInterface fun openChrome() = runOnUiThread { doOpenChrome() }
        @JavascriptInterface fun capture() = runOnUiThread { requestCaptureWithPermissions() }
        @JavascriptInterface fun overlay() = runOnUiThread { doOverlay() }
        @JavascriptInterface fun reset() = runOnUiThread { doReset() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#111318"))
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)

        restoreState(savedInstanceState)

        logEvent("onCreate")
        handleScreenshot(intent)
        timerHandler.post(timerRunnable)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(KEY_TOTAL_AWAY_MS, totalAwayMs)
        outState.putLong(KEY_EFFECTIVE_PENALTY_MS, effectivePenaltyMs)
        outState.putInt(KEY_THRESHOLD_COUNT, thresholdTriggeredCount)
        outState.putBoolean(KEY_MULTIPLIER_ACTIVE, multiplierActive)
        awayStartMs?.let { outState.putLong(KEY_AWAY_START_MS, it) }
    }

    private fun restoreState(saved: Bundle?) {
        if (saved == null) return
        totalAwayMs = saved.getLong(KEY_TOTAL_AWAY_MS, 0L)
        effectivePenaltyMs = saved.getLong(KEY_EFFECTIVE_PENALTY_MS, 0L)
        thresholdTriggeredCount = saved.getInt(KEY_THRESHOLD_COUNT, 0)
        multiplierActive = saved.getBoolean(KEY_MULTIPLIER_ACTIVE, false)
        awayStartMs = if (saved.containsKey(KEY_AWAY_START_MS)) saved.getLong(KEY_AWAY_START_MS) else null
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        val start = awayStartMs
        if (start != null) {
            val elapsed = System.currentTimeMillis() - start
            totalAwayMs += elapsed
            // Правило стенда: при превышении порога ВЕСЬ интервал считается с ×3
            val mult = if (elapsed >= thresholdMs) 3 else 1
            effectivePenaltyMs += elapsed * mult
            if (elapsed >= thresholdMs) {
                thresholdTriggeredCount += 1
                multiplierActive = true
            }
            awayStartMs = null
            logEvent(String.format(Locale.getDefault(), "onResume (отсутствие %.2f с, коэф. ×%d)", elapsed / 1000.0, mult))
        } else {
            logEvent("onResume")
        }
        syncFloatingPanel()
    }

    override fun onPause() {
        super.onPause()
        if (awayStartMs == null) awayStartMs = System.currentTimeMillis()
        logEvent("onPause → старт отсчёта 5.0 с")
        syncFloatingPanel()
        // WebView.onPause() намеренно не вызываем: тикер и панель должны жить в Split Screen
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus && awayStartMs == null) {
            awayStartMs = System.currentTimeMillis()
            logEvent("Focus LOST → старт отсчёта 5.0 с")
            syncFloatingPanel()
        } else if (hasFocus) {
            logEvent("Focus GAINED")
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleScreenshot(intent)
    }

    override fun onDestroy() {
        timerHandler.removeCallbacks(timerRunnable)
        webView.removeJavascriptInterface("Android")
        webView.destroy()
        super.onDestroy()
    }

    // ---------- действия кнопок ----------

    private fun doOpenChrome() {
        val launch = packageManager.getLaunchIntentForPackage("com.android.chrome")
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            Toast.makeText(this, "Chrome не найден", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            setStatus("Разрешите показ поверх других окон и нажмите кнопку снова")
        } else {
            ContextCompat.startForegroundService(this, Intent(this, FloatingPanelService::class.java))
            syncFloatingPanel()
            setStatus("Плавающая панель активна (справа сверху)")
        }
    }

    private fun doReset() {
        awayStartMs = null
        totalAwayMs = 0L
        effectivePenaltyMs = 0L
        thresholdTriggeredCount = 0
        multiplierActive = false
        eventLog.clear()
        logEvent("Сброс счётчиков")
        syncFloatingPanel()
    }

    // ---------- состояние -> HTML ----------

    private fun setStatus(text: String) {
        statusText = text
        pushState()
    }

    private fun logEvent(message: String) {
        eventLog.addFirst("[${timeFormat.format(Date())}] $message")
        while (eventLog.size > 15) eventLog.removeLast()
        if (::webView.isInitialized) pushState()
    }

    private fun pushState() {
        if (!::webView.isInitialized) return
        val start = awayStartMs
        val json = JSONObject().apply {
            put("away", start != null)
            put("curAwayMs", if (start != null) System.currentTimeMillis() - start else 0L)
            put("thresholdMs", thresholdMs)
            put("totalMs", totalAwayMs)
            put("penaltyMs", effectivePenaltyMs)
            put("count", thresholdTriggeredCount)
            put("mult", multiplierActive)
            put("status", statusText)
            put("log", JSONArray(eventLog.toList()))
        }
        webView.evaluateJavascript("window.onNativeState&&window.onNativeState($json)", null)
    }

    private fun syncFloatingPanel() {
        if (!Settings.canDrawOverlays(this)) return
        val start = awayStartMs
        val intent = Intent(this, FloatingPanelService::class.java).apply {
            action = FloatingPanelService.ACTION_UPDATE_STATE
            putExtra(FloatingPanelService.EXTRA_IS_AWAY, start != null)
            putExtra(FloatingPanelService.EXTRA_AWAY_START_MS, start ?: 0L)
            putExtra(FloatingPanelService.EXTRA_MULTIPLIER_ACTIVE, multiplierActive)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    // ---------- захват экрана ----------

    private fun requestCaptureWithPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchScreenCapturePrompt()
        }
    }

    private fun launchScreenCapturePrompt() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capturePermission.launch(manager.createScreenCaptureIntent())
    }

    private fun handleScreenshot(source: Intent?) {
        val path = source?.getStringExtra("screenshot_path") ?: return
        source.removeExtra("screenshot_path")

        val file = File(path)
        if (!file.exists()) return

        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "Отправить изображение нейросети"))
        setStatus("Скриншот готов и передан")
    }
}
